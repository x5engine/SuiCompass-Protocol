#!/bin/bash

# Deploy RPC Proxy Server to Ubuntu Server
# Usage: ./deploy.sh [ssh_key_path]

set -e

SERVER_IP="46.224.114.187"
SERVER_USER="user"
SERVER_DIR="~/casper-ghost-rpc-proxy"
LOCAL_DIR="."

# Use provided SSH key or default
SSH_KEY="${1:-~/.ssh/id_rsa}"
SSH_OPTS="-i $SSH_KEY -o StrictHostKeyChecking=no"

echo "🚀 Deploying RPC Proxy Server to $SERVER_USER@$SERVER_IP..."
echo "🔑 Using SSH key: $SSH_KEY"

# Test SSH connection first
echo "🔍 Testing SSH connection..."
if ! ssh $SSH_OPTS $SERVER_USER@$SERVER_IP "echo 'SSH connection successful'"; then
    echo "❌ SSH connection failed!"
    echo "💡 Make sure:"
    echo "   1. SSH key is at: $SSH_KEY"
    echo "   2. Key has correct permissions: chmod 600 $SSH_KEY"
    echo "   3. Key is added to server: ssh-copy-id -i $SSH_KEY $SERVER_USER@$SERVER_IP"
    exit 1
fi

# Create server directory if it doesn't exist
echo "📁 Creating server directory..."
ssh $SSH_OPTS $SERVER_USER@$SERVER_IP "mkdir -p $SERVER_DIR"

# Copy files to server (exclude node_modules and logs)
echo "📦 Copying files to server..."
rsync -avz --exclude 'node_modules' --exclude 'logs' --exclude '.git' \
    -e "ssh $SSH_OPTS" \
    $LOCAL_DIR/ $SERVER_USER@$SERVER_IP:$SERVER_DIR/

# Install dependencies and start server
echo "⚙️  Installing dependencies and starting server..."
ssh $SSH_OPTS $SERVER_USER@$SERVER_IP << 'ENDSSH'
cd ~/casper-ghost-rpc-proxy
npm install --production
# Install pm2 globally if not installed
npm list -g pm2 || npm install -g pm2
# Stop existing process if running
pm2 stop casper-ghost-rpc-proxy || true
pm2 delete casper-ghost-rpc-proxy || true
# Start with ecosystem config
pm2 start ecosystem.config.js || pm2 start index.js --name casper-ghost-rpc-proxy
pm2 save
pm2 startup || true
pm2 list
ENDSSH

echo ""
echo "✅ Deployment complete!"
echo "📡 Server should be running on http://$SERVER_IP:3001"
echo "🔍 Test: curl http://$SERVER_IP:3001/health"
echo "📝 Server URL for frontend: http://$SERVER_IP:3001/api/rpc"

