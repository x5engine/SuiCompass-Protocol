# Manual Deployment to Ubuntu Server

## Server Details
- **IP:** 46.224.114.187
- **User:** user
- **Directory:** ~/casper-ghost-rpc-proxy

## Quick Deploy (if SSH key is set up)

```bash
cd server
./deploy.sh
```

Or with custom SSH key:
```bash
./deploy.sh ~/.ssh/your_key
```

## Manual Deploy Steps

### 1. SSH into server
```bash
ssh user@46.224.114.187
```

### 2. Create directory and navigate
```bash
mkdir -p ~/casper-ghost-rpc-proxy
cd ~/casper-ghost-rpc-proxy
```

### 3. Copy files from local machine
From your local machine:
```bash
cd server
scp -r * user@46.224.114.187:~/casper-ghost-rpc-proxy/
```

### 4. Install dependencies
On server:
```bash
cd ~/casper-ghost-rpc-proxy
npm install --production
```

### 5. Install PM2 (process manager)
```bash
npm install -g pm2
```

### 6. Start server with PM2
```bash
pm2 start ecosystem.config.js
# Or if ecosystem.config.js doesn't work:
pm2 start index.js --name casper-ghost-rpc-proxy
pm2 save
pm2 startup  # This will show command to run as root for auto-start
```

### 7. Check status
```bash
pm2 list
pm2 logs casper-ghost-rpc-proxy
```

### 8. Test server
```bash
curl http://localhost:3001/health
```

### 9. Open firewall port (if needed)
```bash
sudo ufw allow 3001/tcp
```

## Server URL

After deployment, your server will be available at:
- **Health:** http://46.224.114.187:3001/health
- **RPC Proxy:** http://46.224.114.187:3001/api/rpc

## Update Frontend

Set environment variable:
```bash
VITE_RPC_PROXY_URL=http://46.224.114.187:3001/api/rpc
```

Then rebuild and redeploy frontend:
```bash
npm run build
firebase deploy --only hosting
```

## PM2 Commands

```bash
pm2 list                    # List all processes
pm2 logs casper-ghost-rpc-proxy  # View logs
pm2 restart casper-ghost-rpc-proxy  # Restart
pm2 stop casper-ghost-rpc-proxy    # Stop
pm2 delete casper-ghost-rpc-proxy  # Remove
```

