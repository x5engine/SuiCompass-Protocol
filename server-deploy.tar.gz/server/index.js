/**
 * RPC Proxy Server for CasperGhost
 * Bypasses CORS issues by proxying RPC calls server-side
 */

const express = require('express');
const cors = require('cors');
const fetch = require('node-fetch');

const app = express();
const PORT = process.env.PORT || 3001;

// Enable CORS for all routes
app.use(cors());
app.use(express.json());

// CSPR.cloud access token (from .workspace/rpc.md)
const CSPR_CLOUD_TOKEN = '019b83db-910e-7a93-a378-310a6833e1e5';

// RPC endpoints to try in order
const RPC_ENDPOINTS = [
  {
    url: 'https://node.testnet.cspr.cloud/rpc',
    requiresAuth: true,
    token: CSPR_CLOUD_TOKEN,
  },
  {
    url: 'https://node.testnet.casper.network/rpc',
    requiresAuth: false,
  },
  {
    url: 'https://public-casper.nownodes.io/rpc',
    requiresAuth: false,
  },
];

/**
 * Proxy RPC endpoint
 * Tries multiple RPC endpoints until one succeeds
 */
app.post('/api/rpc', async (req, res) => {
  try {
    const requestBody = req.body;

    // Try each endpoint until one works
    for (let i = 0; i < RPC_ENDPOINTS.length; i++) {
      const endpoint = RPC_ENDPOINTS[i];
      
      try {
        const headers = {
          'Content-Type': 'application/json',
        };

        if (endpoint.requiresAuth && endpoint.token) {
          headers['Authorization'] = endpoint.token;
        }

        const response = await fetch(endpoint.url, {
          method: 'POST',
          headers,
          body: JSON.stringify(requestBody),
        });

        if (response.ok) {
          const data = await response.json();
          return res.status(200).json(data);
        }

        // If not ok and this is the last endpoint, return error
        if (i === RPC_ENDPOINTS.length - 1) {
          const errorData = await response.json().catch(() => ({ 
            error: { 
              code: response.status, 
              message: 'RPC request failed' 
            } 
          }));
          return res.status(response.status).json(errorData);
        }
      } catch (error) {
        // If this is the last endpoint, return error
        if (i === RPC_ENDPOINTS.length - 1) {
          return res.status(500).json({
            error: {
              code: -32000,
              message: 'All RPC endpoints failed',
              data: error.message,
            },
          });
        }
        // Otherwise, try next endpoint
        continue;
      }
    }
  } catch (error) {
    return res.status(500).json({
      error: {
        code: -32603,
        message: 'Internal server error',
        data: error.message,
      },
    });
  }
});

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'casper-ghost-rpc-proxy' });
});

app.listen(PORT, () => {
  console.log(`🚀 RPC Proxy Server running on port ${PORT}`);
  console.log(`📡 Proxy endpoint: http://localhost:${PORT}/api/rpc`);
});

