# RPC Proxy Server

This server acts as a proxy for Casper Network RPC calls, bypassing CORS restrictions in production.

## Setup

1. Install dependencies:
```bash
cd server
npm install
```

2. Start the server:
```bash
npm start
```

For development with auto-reload:
```bash
npm run dev
```

## Environment Variables

- `PORT` - Server port (default: 3001)

## Endpoints

### POST `/api/rpc`
Proxies RPC calls to Casper Network nodes with proper CORS headers and authentication.

**Request Body:**
```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "chain_get_state_root_hash",
  "params": []
}
```

**Response:**
Returns the RPC response from the Casper Network node.

### GET `/health`
Health check endpoint.

## Deployment

Deploy this server to any Node.js hosting service:
- **Vercel**: `vercel --prod`
- **Railway**: Connect GitHub repo
- **Render**: Create Web Service
- **Heroku**: `git push heroku main`
- **DigitalOcean App Platform**: Connect repo

After deployment, set `VITE_RPC_PROXY_URL` in your frontend environment to point to your deployed server URL.

## How It Works

1. Frontend makes RPC request to `/api/rpc` on this server
2. Server adds Authorization header for CSPR.cloud endpoints
3. Server tries multiple RPC endpoints in order until one succeeds
4. Server returns response to frontend with proper CORS headers

This completely bypasses browser CORS restrictions since the request is server-to-server.

